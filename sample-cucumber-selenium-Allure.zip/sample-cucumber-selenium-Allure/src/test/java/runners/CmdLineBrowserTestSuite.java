package runners;

public class CmdLineBrowserTestSuite extends BaseRunner {}