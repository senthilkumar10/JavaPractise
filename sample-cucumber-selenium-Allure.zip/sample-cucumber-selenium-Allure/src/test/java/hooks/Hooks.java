package hooks;

import java.io.IOException;

import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {

//    @Before
//    public void startUp(Scenario scenario) throws IOException {
//    }
//
//    @After(order=40)
//    public void closeDown(Scenario scenario) throws InterruptedException {
//    }
//
//    @After(order=40)
//    public void closeDown2(Scenario scenario) throws InterruptedException {
//    }
}
