package automation.library.mq.core;


public class Constants {
    public static final String BASEPATH = System.getProperty("user.dir") + "/src/test/resources/";
}
