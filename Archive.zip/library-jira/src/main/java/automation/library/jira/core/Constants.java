package automation.library.jira.core;


public class Constants {
    public static final String BASEPATH = System.getProperty("user.dir") + "/src/test/resources/";
    public static final String JIRAPATH = BASEPATH + "/config/jira/";
}
